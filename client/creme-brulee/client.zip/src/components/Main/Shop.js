import React from 'react'
import Card from 'react-bootstrap/Card';
import { Button,Breadcrumb } from 'react-bootstrap';

export default function Shop() {
    return (
        <>
         <Breadcrumb style={{ marginTop: 150 }}>
                <Breadcrumb.Item href="/">Home</Breadcrumb.Item>
                <Breadcrumb.Item href="/add-items">
                    Add items
                </Breadcrumb.Item>
                <Breadcrumb.Item href="/add-items">
                    Cake
                </Breadcrumb.Item>
                <Breadcrumb.Item href="/add-items">
                    Donut
                </Breadcrumb.Item>
                <Breadcrumb.Item href="/add-items">
                    Dessert
                </Breadcrumb.Item>
                <Breadcrumb.Item active>Data</Breadcrumb.Item>
            </Breadcrumb>

                <Card style={{ width: '18rem',marginTop:100 }}>
                    <Card.Img variant="top" src="https://swissdelight.qodeinteractive.com/wp-content/uploads/2021/02/shop-img2.jpg" />
                    <Card.Body>
                        <Card.Title>Mimosa</Card.Title>
                        <Card.Text>
                           Chocalate,Hot choco
                           $46
                        </Card.Text>
                        <Button variant="dark">View</Button>
                    </Card.Body>
                </Card>
           
        </>
    )
}
