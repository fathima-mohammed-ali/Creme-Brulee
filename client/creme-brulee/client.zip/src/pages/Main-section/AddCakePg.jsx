import React from 'react'
import AddCake from '../../components/Main/AddCake'
import MainNav from '../../components/Nav/MainNav'

export default function AddCakePg() {
  return (
   <>
   <MainNav/>
   <div className='container'><AddCake/>
   </div>
   
   </>
  )
}
