import React from 'react'
import MainNav from '../../components/Nav/MainNav'
import AddDonut from '../../components/Main/AddDonut'
export default function AddDonutPg() {
  return (
    <>
    <MainNav/>
   <div className='container'><AddDonut/>
   </div>
    </>
  )
}
