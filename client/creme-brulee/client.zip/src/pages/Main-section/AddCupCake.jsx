import React from 'react'
import MainNav from '../../components/Nav/MainNav'
import AddCupCake from '../../components/Main/AddCupCake'
export default function AddCupCakePg() {
  return (
   <>
    <MainNav />
            <div className='container'><AddCupCake />
            </div>

   
   </>
  )
}
