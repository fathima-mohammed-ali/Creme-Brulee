import React from 'react'
import MainNav from '../../components/Nav/MainNav'
import AddDessert from '../../components/Main/AddDessert'
export default function AddDesert() {
    return (
        <>
            <MainNav />
            <div className='container'><AddDessert />
            </div>

        </>
    )
}
